import os
from flask import Flask, render_template
import grpc
from recommendations_pb2 import BookCategory, RecommendationRequest
from recommendations_pb2_grpc import RecommendationsStub

# Создание приложения Flask
app = Flask(__name__)

# Получение хоста рекомендаций из переменной окружения, если не задано - используется localhost
recommendations_host = os.getenv("RECOMMENDATIONS_HOST", "localhost")

# Настройка gRPC канала
recommendations_channel = grpc.insecure_channel(f"{recommendations_host}:50051")

# Создание клиента для рекомендаций
recommendations_client = RecommendationsStub(recommendations_channel)

@app.route("/")
def render_homepage():
    # Создание запроса рекомендаций для категории SCIENCE_FICTION и 2 результатов
    recommendations_request = RecommendationRequest(
        user_id=1, category=BookCategory.SCIENCE_FICTION, max_results=2
    )
    
    # Получение ответа от сервера рекомендаций
    recommendations_response = recommendations_client.Recommend(recommendations_request)
    
    # Рендеринг главной страницы с полученными рекомендациями
    return render_template(
        "homepage.html",
        recommendations=recommendations_response.recommendations,
    )

if __name__ == '__main__':
    # Запуск приложения Flask на порту 5001
    app.run(host='0.0.0.0', port=5001)
